# -*-coding:utf-8-*-
# Copyright (c) 2020 DJI.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License in the file LICENSE.txt or at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from . import module
from . import protocol
from . import logger
from . import dds


__all__ = ['AiModule']


class AiModuleEvent(dds.Subject):
    name = "ai_event"
    cmdset = 0x3f
    cmdid = 0xda
    type = dds.DDS_SUB_TYPE_EVENT

    def __init__(self):
        self._ai_info = []
        self._num = 0

    def data_info(self):
        return self._num, self._ai_info

    def decode(self, buf):
        self._num, self._ai_info = buf


class AiModule(module.Module):
    _host = protocol.host2byte(15, 1)

    def __init__(self, robot):
        super().__init__(robot)

    def sub_ai_event(self, callback=None, *args, **kw):
        """ AI数据订阅

        :param callback: 回调函数, 返回数据 (id, x, y, w, g, C)：

                :id: 目标对象ID
                :x: 目标图像的坐标x
                :y: 目标图像的坐标y
                :w: 目标图像的像素宽度
                :h: 目标图像的像素高度
                :C: 目标的置信度

        :param args: 可变参数
        :param kw: 关键字参数
        :return: bool: 事件订阅结果
        """
        sub = self._robot.dds
        subject = AiModuleEvent()
        protocol.ProtoAiModuleEvent()
        return sub.add_subject_event_info(subject, callback, args, kw)


    def unsub_ai_event(self):
        """ 取消AI数据订阅

        :return: bool: 取消数据订阅结果
        """
        sub = self._robot.dds
        subject = AiModuleEvent()
        return sub.del_subject_event_info(subject)


